﻿namespace BookReviewHub.Api.Models;

using Microsoft.AspNetCore.Identity;

public class ApplicationUser : IdentityUser
{
    // You can extend user properties here (optional)
}
